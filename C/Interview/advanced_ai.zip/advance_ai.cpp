#include<iostream>
#include<vector>

#define BLOCK -1

using std::vector;
using std::cout;
using std::endl;

void find_max_path(
    vector<vector<int>> graph,
    vector<int>& nodes,
    int start,
    int& weight_sum,
    int& max_weight,
    vector<int>& pth,
    vector<int>& best_pth
    );


int main() {
    // initilization
    vector<int> middle, res, nodes{1, 2, 2};
    vector<vector<int>> graph{{BLOCK, 1, 1}, {BLOCK, BLOCK, 1}, {BLOCK, BLOCK, -1}};
    int weight_sum, max_weight;
    // start status
    middle.push_back(0);
    weight_sum = 1;
    max_weight = -1;

    find_max_path(graph, nodes, 0, weight_sum, max_weight, middle, res);

    // print result
    cout << "max weight sum is: " << max_weight << endl;
    cout << "best path is: ";
    for (auto& el : res) {
        cout << el << ", ";
    }
    cout << endl;
    return 0;
}


void find_max_path(
    vector<vector<int>> graph,
    vector<int>& nodes,
    int start,
    int& weight_sum,
    int& max_weight,
    vector<int>& pth,
    vector<int>& best_pth
    ) {
    int n_nodes = nodes.size();
    int curr;
    bool has_next = false;
    for (int i{0}; i < n_nodes; ++i) {
        curr = graph[start][i];
        if (curr != BLOCK) {
            has_next = true;
            weight_sum += nodes[i];
            pth.push_back(i);
            find_max_path(graph, nodes, i, weight_sum, max_weight, pth, best_pth);
            pth.pop_back();
            weight_sum -= nodes[i];
        }
    }

    if (!has_next) {
        if (weight_sum > max_weight) {
            max_weight = weight_sum;
            best_pth = pth;
        }
    }
}
